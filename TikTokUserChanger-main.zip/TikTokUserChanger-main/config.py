token = "botToken" # Change it to yours
api_id = 2040 # api_id of Telegram Desktop, better change to yours
api_hash = "b18441a1ff607e10a989891a5462e627" # api_hash of Telegram Desktop, better change to yours